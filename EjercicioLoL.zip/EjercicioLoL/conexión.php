<?php
    return [
        "nombreHost" => "localhost",
        "usuario" => "usuarioLoL",
        "contraseña" => "1234",
        "nombreBD" => "lol"
    ];
?>